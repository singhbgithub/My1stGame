// assignment 4
// pair 041
// Singh, Bhavneet
// singhb
// Pang, Bo
// pangbo

import tester.*;

//represents test for all classes in the IBook java file
class ExamplesIBook {
    ExamplesIBook() {
    }

    IBook b1 = new Book("Bobby", "Bobbys", 4000);
    IBook rb1 = new RefBook("Bo", 4100);
    IBook ab1 = new AudioBook("cliff", "cliffstupid", 5000);

    boolean testAll(Tester t) {
        return t.checkExpect(this.b1.daysOverdue(4002), -12)
                && t.checkExpect(this.rb1.daysOverdue(4200), 98)
                && t.checkExpect(this.ab1.daysOverdue(5100), 86)
                && t.checkExpect(this.b1.isOverdue(4002), false)
                && t.checkExpect(this.rb1.isOverdue(4200), true)
                && t.checkExpect(this.ab1.isOverdue(5100), true)
                && t.checkExpect(this.b1.computeFine(4002), 0)
                && t.checkExpect(this.b1.computeFine(4050), 360)
                && t.checkExpect(this.rb1.computeFine(4200), 980)
                && t.checkExpect(this.rb1.computeFine(4102), 0)
                && t.checkExpect(this.ab1.computeFine(5001), 0)
                && t.checkExpect(this.ab1.computeFine(5100), 1720);
    }
}
