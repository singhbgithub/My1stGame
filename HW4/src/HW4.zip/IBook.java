// assignment 4
// pair 041
// Singh, Bhavneet
// singhb
// Pang, Bo
// pangbo

//this represents the interface IBook
interface IBook {
    // computes the days overdue of this IBook given
    // today's date.
    int daysOverdue(int date);

    // is this Book overdue?
    Boolean isOverdue(int date);

    // computes the fine of this overdue Book.
    int computeFine(int date);
}

//this represents the abstract class Abook
abstract class ABook implements IBook {
    String title;
    int dayTaken;

    ABook(String title, int dayTaken) {
        this.title = title;
        this.dayTaken = dayTaken;
    }

    /*
     * TEMPLATE: 
     * FIELDS: 
     * ...this.title...                              -- String
     * ...this.dayTaken...                           -- int
     * 
     * METHODS: 
     * ...this.daysOverdue(int)...                   -- int 
     * ...this.isOverdue(int)...                     -- boolean 
     * ...this.computeFine(int)...                   -- int
     * 
     * METHODS FOR FIELDS: 
     * The methods for fields are built-in (String class)
     * The methods for fields are built-in (int class)
     */

    // computes the days overdue of this IBook given
    // today's date.
    public int daysOverdue(int date) {
        return date - this.dayTaken - 14;
    }

    // is this Book overdue?
    public Boolean isOverdue(int date) {
        return this.daysOverdue(date) > 0;
    }

    // computes the fine of this overdue Book.
    public int computeFine(int date) {
        if (this.isOverdue(date))
            return 10 * this.daysOverdue(date);
        else
            return 0;
    }
}

//this represents the class Book
class Book extends ABook {
    String author;

    Book(String title, String author, int dayTaken) {
        super(title, dayTaken);
        this.author = author;
    }

    /*
     * TEMPLATE: 
     * FIELDS: 
     * ...this.title...                              -- String
     * ...this.dayTaken...                           -- int
     * ...this.author...                             -- String
     * 
     * METHODS: 
     * ...this.daysOverdue(int)...                   -- int 
     * ...this.isOverdue(int)...                     -- boolean 
     * ...this.computeFine(int)...                   -- int
     * 
     * METHODS FOR FIELDS: 
     * The methods for fields are built-in (String class)
     * The methods for fields are built-in (int class)
     */
}

//this represents the class RefBook
class RefBook extends ABook {
    RefBook(String title, int dayTaken) {
        super(title, dayTaken);
    }

    /*
     * TEMPLATE: 
     * FIELDS: 
     * ...this.title...                              -- String
     * ...this.dayTaken...                           -- int
     * 
     * METHODS: 
     * ...this.daysOverdue(int)...                   -- int 
     * ...this.isOverdue(int)...                     -- boolean 
     * ...this.computeFine(int)...                   -- int
     * 
     * METHODS FOR FIELDS: 
     * The methods for fields are built-in (String class)
     * The methods for fields are built-in (int class)
     */

    // computes the days overdue of this IBook given
    // today's date.
    public int daysOverdue(int date) {
        return date - this.dayTaken - 2;
    }
}

//this represents the class AudioBook
class AudioBook extends ABook {
    String author;

    AudioBook(String title, String author, int dayTaken) {
        super(title, dayTaken);
        this.author = author;
    }

    /*
     * TEMPLATE: 
     * FIELDS: 
     * ...this.title...                              -- String
     * ...this.dayTaken...                           -- int
     * ...this.author...                             -- String 
     * 
     * METHODS: 
     * ...this.daysOverdue(int)...                   -- int 
     * ...this.isOverdue(int)...                     -- boolean 
     * ...this.computeFine(int)...                   -- int
     * 
     * METHODS FOR FIELDS: 
     * The methods for fields are built-in (String class)
     * The methods for fields are built-in (int class)
     */

    // computes the fine of this overdue Book.
    public int computeFine(int date) {
        if (this.isOverdue(date))
            return 20 * this.daysOverdue(date);
        else
            return 0;
    }
}
