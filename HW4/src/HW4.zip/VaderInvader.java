// assignment 4
// pair 041
// Singh, Bhavneet
// singhb
// Pang, Bo
// pangbo

import tester.*;
import javalib.funworld.*;
import javalib.worldcanvas.*;
import javalib.worldimages.*;
import javalib.colors.*;
import java.awt.Color;
import java.util.*;

//this class represents the vaderinvader world/game
class VaderInvader extends World {
    // darth vader (the enemy) falling from the sky
    Enemy darthvader;

    // the hero, bo, who can move across the screen and
    // fire lasers to "kill" the enemy
    Hero bo;

    // Deadly beams that are fire up the screen from
    // the position of the hero
    ILoL lasers;

    // An integer that represents how many darthvaders you killed
    int score;

    // CONSTANTS:
    int width = 500;
    int height = 500;

    VaderInvader(Enemy darthvader, Hero bo, ILoL lasers, int score) {
        this.darthvader = darthvader;
        this.bo = bo;
        this.lasers = lasers;
        this.score = score;
    }
    
     /*
     * TEMPLATE: 
     * FIELDS: 
     * ...this.darthvader...                         -- Enemy 
     * ...this.bo...                                 -- Hero
     * ...this.lasers...                             -- ILoL
     * ...this.score...                              -- int
     * 
     * METHODS: 
     * ...this.onTick()...                           -- World 
     * ...this.onKeyEvent(String)...                 -- World 
     * ...this.makeImage()...                        -- WorldImage 
     * ...this.lastImage(String)...                  -- WorldImage 
     * ...this.worldEnds()...                        -- WorldEnd
     * 
     * METHODS FOR FIELDS:
     * ...this.darthvader.fasterVader()...           -- Enemy
     * ...this.darthvader.fall()...                  -- Enemy
     * ...this.darthvader.hitGround(int)...          -- boolean
     * ...this.darthvader.vaderImage()...            -- WorldImage
     * 
     * ...this.bo.onKeyEvent()...                    -- Hero
     * ...this.bo.moveLeft()...                      -- Hero
     * ...this.bo.moveRight()...                     -- Hero
     * ...this.bo.heroImage()...                     -- WorldImage
     * 
     * ...this.lasers.onKeyEvent(String)...          -- ILoL
     * ...this.lasers.collide(Enemy)...              -- boolean
     * ...this.lasers.removeCollidedLasers(Enemy)... -- ILoL
     * ...this.lasers.removeOutOfBoundLasers()...    -- ILoL
     * ...this.lasers.moveLasers()...                -- ILoL
     * ...this.lasers.lasersImage()...               -- WorldImage
     */


    // produce a new vaderinvader out of this one after one tick has passed
    // this vaderinvader's enemy moves down the screen,this vaderinvader's
    // ILoL, advance up the screen and are culled off when they reach the
    // top, or if they hit this vaderinvader's enemy
    // this vaderinvader's hero does not move
    // if this vaderinvader's ILoL collides with this vaderinvader's enemy
    // then it will produce a new vaderinvader with a faster enemy and 1
    // added to the score
    public VaderInvader onTick() {   
        if (this.lasers.collide(this.darthvader))
            return new VaderInvader(this.darthvader.fasterVader().fall(),
                    this.bo, this.lasers.removeCollidedLasers(this.darthvader)
                            .removeOutOfBoundLasers()
                            .moveLasers(this.darthvader), this.score + 1);
        else
            return new VaderInvader(this.darthvader.fall(), this.bo,
                    this.lasers.removeOutOfBoundLasers().moveLasers(
                            this.darthvader), this.score);
    } //I did not use world because it required a class cast in the test case
    //for when this vaderinvader's laser collides with this vaderinvader's enemy

    // produce a new vaderinvader out of this one in response to a key event,
    // this vaderinvader's enemy does not move, this vaderinvader's ILoL,
    // is unaffected unless, the given key is spacebar, then one laser will
    // be added to the this vaderinvader's ILoL and this vaderinvader's hero,
    // may move left or right, if the given key is "left" or "right"
    // respectively
    public World onKeyEvent(String ke) {
        return new VaderInvader(this.darthvader, this.bo.onKeyEvent(ke,
                this.darthvader), this.lasers.onKeyEvent(ke, this.bo),
                this.score);
    }

    // produce the image that represents this vaderinvader
    public WorldImage makeImage() {
        return this.lasers.lasersImage().overlayImages(
                this.darthvader.enemyImage(), this.bo.heroImage(),
                new TextImage(new Posn(width - 30, 10),
                        "Score: " + Integer.toString(this.score),
                        Color.green));
    }

    // After each tick checks if this vaderinvader's enemy reaches
    // the bottom of the screen - if so, the game ends
    public WorldEnd worldEnds() {
        if (this.darthvader.hitGround(height))
            return new WorldEnd(true, this.makeImage().overlayImages(
                    new TextImage(new Posn(width / 2, height / 2),
                            "You Lose, Final Score: " + 
                             Integer.toString(this.score),
                            Color.black)));
        else
            return (new WorldEnd(false, this.makeImage()));
    }

    // produce the last image if this vaderinvader's enemy
    // reaches the bottom of the screen
    public WorldImage lastImage(String s) {
        return this.makeImage().overlayImages(
                new TextImage(new Posn(width / 2, height / 2), s, Color.black));
    }
}

//this class represents an enemy
class Enemy {
    CartPt position;
    int speed;
    String name;

    Enemy(CartPt position, int speed, String name) {
        this.position = position;
        this.speed = speed;
        this.name = name;
    }
    
    /*
     * TEMPLATE: 
     * FIELDS: 
     * ...this.position...                           -- CartPt 
     * ...this.speed...                              -- int
     * ...this.name...                               -- String
     * 
     * METHODS: 
     * ...this.fasterVader()...                      -- Enemy
     * ...this.fall()...                             -- Enemy
     * ...this.hitGround(int)...                     -- boolean
     * ...this.vaderImage()...                       -- WorldImage
     * 
     * METHODS FOR FIELDS:
     * ...this.position.randV()...                   -- CartPt
     * ...this.position.moveBy(int, int)...          -- CartPt
     * ...this.position.disTo(CartPt)...             -- double
     * ...this.position.collidePos(CartPt)...        -- boolean
     * ...this.position.outOfBoundsp()...            -- boolean
     * ...this.position.movePointUp(Enemy)...        -- CartPt
     */


    // produce a faster enemy out of this one
    public Enemy fasterVader() {
        return new Enemy(this.position.randV(), this.speed + 1, this.name);
    }

    // move this enemy down by its speed
    public Enemy fall() {
        return new Enemy(this.position.moveBy(0, this.speed), this.speed,
                this.name);
    }

    // did this enemy hit the ground?
    public Boolean hitGround(int height) {
        return this.position.y >= height;
    }

    // produce the image of this enemy at this position
    public WorldImage enemyImage() {
        return new FromFileImage(this.position, this.name);
    }
}

//this class represents a hero 
class Hero {
    CartPt position;

    Hero(CartPt position) {
        this.position = position;
    }
    
    /*
     * TEMPLATE: 
     * FIELDS: 
     * ...this.position...                           -- CartPt 
     * 
     * METHODS: 
     * ...this.onKeyEvent(String, Enemy)...          -- Hero
     * ...this.moveLeft(Enemy)...                    -- Hero
     * ...this.moveRight(Enemy)...                   -- Hero
     * ...this.heroImage()...                        -- WorldImage
     * 
     * METHODS FOR FIELDS:
     * ...this.position.randV()...                   -- CartPt
     * ...this.position.moveBy(int, int)...          -- CartPt
     * ...this.position.disTo(CartPt)...             -- double
     * ...this.position.collidePos(CartPt)...        -- boolean
     * ...this.position.outOfBoundsp()...            -- boolean
     * ...this.position.movePointUp(Enemy)...        -- CartPt
     */

    // move this hero left and right in response to a given string
    public Hero onKeyEvent(String ke, Enemy enm) {
        if (ke.equals("left"))
            return this.moveLeft(enm);
        else if (ke.equals("right"))
            return this.moveRight(enm);
        else
            return this;
    }

    // from this Hero produce another Hero which moved left a bit (5 pixels)
    public Hero moveLeft(Enemy enm) {
        return new Hero(this.position.moveBy(enm.speed * -1, 0));
    }

    // from this Hero produce another Hero which moved right a bit (5 pixels)
    public Hero moveRight(Enemy enm) {
        return new Hero(this.position.moveBy(enm.speed, 0));
    }

    // produce the image of this Hero at this position
    public WorldImage heroImage() {
        return new RectangleImage(this.position, 30, 20, Color.CYAN);
    }
}

//this class represents a list of lasers
//which can be either empty or nonempty
interface ILoL {

    // checks if this list of lasers has a new laser
    // added to the scene or not, in correspondence
    // to a given string - if so it adds a new laser
    // to this list of lasers at the position of the
    // given hero
    public ILoL onKeyEvent(String ke, Hero bop);

    // did any of the lasers in this list of lasers collide
    // with the given enemy?
    public boolean collide(Enemy enm);

    // remove lasers that collided with the given enemy
    // in this list of lasers
    public ILoL removeCollidedLasers(Enemy enm);

    // remove lasers that are out of bounds
    // in this list of lasers
    public ILoL removeOutOfBoundLasers();

    // moves every laser in this list of lasers up the screen
    // by the speed of the given enemy
    public ILoL moveLasers(Enemy enm);

    // produce the image of this list of lasers
    public WorldImage lasersImage();

}

//this class represents an empty list of lasers
class MtLoL implements ILoL {
    MtLoL() {
    }
    
    /*TEMPLATE:
     * FIELDS:
     * There are no fields for this class
     * 
     * METHODS:
     * ...this.onKeyEvent(String, Hero)...           -- ILoL
     * ...this.collide(Enemy)...                     -- boolean
     * ...this.removeCollidedLasers(Enemy)...        -- ILoL
     * ...this.removeOutOfBoundLasers()...           -- ILoL
     * ...this.moveLasers(Enemy)...                  -- ILoL
     * ...this.lasersImage()...                      -- WorldImage
     * 
     * METHODS FOR FIELDS:
     * There are no fields, therefore there are no methods
     * for fields
     */

    // CONSTANTS:
    Color spaceblue = new Color(50, 150, 255);
    int width = 500;
    int height = 500;
    WorldImage background = new RectangleImage(new Posn(width / 2, height / 2),
            width, height, spaceblue);

    // add one laser into this empty list of lasers
    // when the given string is "up" at the position of
    // the given hero
    public ILoL onKeyEvent(String ke, Hero bop) {
        if (ke.equals("up"))
            return new ConsLoL(new Laser(2, bop.position), this);
        else
            return this;
    }

    // did any of the lasers in this empty list of lasers
    // collide with the given enemy?
    public boolean collide(Enemy enm) {
        return false;
    }

    // remove lasers that collide with the given enemy
    // from this empty list of lasers
    public ILoL removeCollidedLasers(Enemy enm) {
        return this;
    }

    // remove out of bound lasers from this empty list of lasers
    public ILoL removeOutOfBoundLasers() {
        return this;
    }

    // moves this empty list of lasers up the screen
    // by the speed of the given enemy
    public ILoL moveLasers(Enemy enm) {
        return this;
    }

    // produce the image of this empty list of lasers
    // of lasers
    public WorldImage lasersImage() {
        return this.background;
    }
}

//this class represents a non empty list of lasers
class ConsLoL implements ILoL {
    Laser first;
    ILoL rest;

    ConsLoL(Laser first, ILoL rest) {
        this.first = first;
        this.rest = rest;
    }
    
    /*TEMPLATE:
     * FIELDS:
     * ...this.first...                              -- Laser
     * ...this.rest...                               -- ILoL
     * 
     * METHODS:
     * ...this.onKeyEvent(String, Hero)...           -- ILoL
     * ...this.collide(Enemy)...                     -- boolean
     * ...this.removeCollidedLasers(Enemy)...        -- ILoL
     * ...this.removeOutOfBoundLasers()...           -- ILoL
     * ...this.moveLasers(Enemy)...                  -- ILoL
     * ...this.lasersImage()...                      -- WorldImage
     * 
     * METHODS FOR FIELDS:
     * ...this.first.collideV(Enemy)...                    -- boolean
     * ...this.first.outOfBoundsp()...                     -- boolean
     * ...this.first.moveLaser(Enemy)...                   -- Laser
     * ...this.first.laserImage()...                       -- WorldImage
     * 
     * ...this.rest.onKeyEvent(String, Hero)...           -- ILoL
     * ...this.rest.collide(Enemy)...                     -- boolean
     * ...this.rest.removeCollidedLasers(Enemy)...        -- ILoL
     * ...this.rest.removeOutOfBoundLasers()...           -- ILoL
     * ...this.rest.moveLasers(Enemy)...                  -- ILoL
     * ...this.rest.lasersImage()...                      -- WorldImage
     */

    // add one laser into this non empty list of lasers
    // when the given string is "up" at the position of the
    // given hero
    public ILoL onKeyEvent(String ke, Hero bop) {
        if (ke.equals("up"))
            return new ConsLoL(new Laser(2, bop.position), this);
        else
            return this;
    }

    // did any of the lasers in this non empty list of lasers
    // collide with the given enemy?
    public boolean collide(Enemy enm) {
        return this.first.collideV(enm) || this.rest.collide(enm);
    }

    // remove lasers that collide with the given enemy
    // from this non empty list of lasers
    public ILoL removeCollidedLasers(Enemy enm) {
        if (this.first.collideV(enm))
            return this.rest.removeCollidedLasers(enm);
        else
            return new ConsLoL(this.first, this.rest.removeCollidedLasers(enm));
    }

    // remove out of bound lasers from this non empty list of lasers
    public ILoL removeOutOfBoundLasers() {
        if (this.first.outOfBoundsp())
            return this.rest.removeOutOfBoundLasers();
        else
            return new ConsLoL(this.first, this.rest.removeOutOfBoundLasers());
    }

    // move this non empty list of lasers up the screen
    // by the speed of the given enemy
    public ILoL moveLasers(Enemy enm) {
        return new ConsLoL(this.first.moveLaser(enm), 
                this.rest.moveLasers(enm));
    }

    // produce the image of this non empty list of lasers
    public WorldImage lasersImage() {
        return this.rest.lasersImage().overlayImages(this.first.laserImage());
    }
}

//This class represents a laser
class Laser {
    int size;
    CartPt position;

    Laser(int size, CartPt position) {
        this.size = size;
        this.position = position;
    }
    
    /* TEMPLATE:
     * FIELDS:
     * ...this.size...                               -- int
     * ...this.position...                           -- CartPt
     * 
     * METHODS:
     * ...this.collideV(Enemy)...                    -- boolean
     * ...this.outOfBoundsp()...                     -- boolean
     * ...this.moveLaser(Enemy)...                   -- Laser
     * ...this.laserImage()...                       -- WorldImage
     * 
     * METHODS FOR FIELDS:
     * ...this.position.randV()...                   -- CartPt
     * ...this.position.moveBy(int, int)...          -- CartPt
     * ...this.position.disTo(CartPt)...             -- double
     * ...this.position.collidePos(CartPt)...        -- boolean
     * ...this.position.outOfBoundsp()...            -- boolean
     * ...this.position.movePointUp(Enemy)...        -- CartPt
     */

    // did this laser collide with the given enemy?
    public boolean collideV(Enemy enm) {
        return this.position.collidePos(enm.position);
    }

    // is this laser out of bounds?
    public boolean outOfBoundsp() {
        return this.position.outOfBoundsp();
    }

    // move this laser up the screen
    // by the speed of the given enemy
    public Laser moveLaser(Enemy enm) {
        return new Laser(this.size, this.position.movePointUp(enm));
    }

    // produce the image of this laser
    public WorldImage laserImage() {
        return new RectangleImage(this.position, this.size, 2 * this.size,
                Color.RED);
    }
}


//This class represents a set of cartesian points
//primarily used to denote the location of an image
//and how we can manipulate it
class CartPt extends Posn {
    CartPt(int x, int y) {
        super(x, y);
    }
    
   /* TEMPLATE:
    * FIELDS:
    * ...this.x...                                   -- int
    * ...this.y...                                   -- int
    * 
    * METHODS:
    * ...this.randV()...                             -- CartPt
    * ...this.moveBy(int, int)...                    -- CartPt
    * ...this.disTo(CartPt)...                       -- double
    * ...this.collidePos(CartPt)...                  -- boolean
    * ...this.outOfBoundsp()...                      -- boolean
    * ...this.movePointUp(Enemy)...                  -- CartPt
    * 
    * METHODS FOR FIELDS:
    * The methods for fields are built-in (Integer class)
    */

    // a random number generator
    public Random rand = new Random();

    // produce a random cartesian point from this cartesian point
    // within the boundaries of the scene
    public CartPt randV() {
        return new CartPt(30 + rand.nextInt(440), 0);
    }

    // produce a cartesian point move by the given distances, x and y,
    // from this cartesian point
    public CartPt moveBy(int dx, int dy) {
        return new CartPt(this.x + dx, this.y + dy);
    }

    // Compute the distance from this cartesian point to the given one
    public double disTo(CartPt that) {
        return Math.sqrt((this.x - that.x) * (this.x - that.x)
                + (this.y - that.y) * (this.y - that.y));
    }

    // did this cartesian point collide with the given one?
    public boolean collidePos(CartPt enmpt) {
        return this.disTo(enmpt) < 20;
    }

    // is this cartesian point out of bounds?
    public boolean outOfBoundsp() {
        return this.y < 1;
    }

    // move this cartesian point up the screen
    // by the speed of the given enemy
    public CartPt movePointUp(Enemy enm) {
        return new CartPt(this.x, this.y - enm.speed);
    }
}